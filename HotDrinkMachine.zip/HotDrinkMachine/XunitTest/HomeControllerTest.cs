using DataAccess.Entities;
using HotDrinkMachine.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace XunitTest
{
    //logic Test
    public class HomeControllerTest
    {
        [Fact]
        public void Test_Index_Returns_DrinkCount()
        {
            //Arrange
            var controller = new HomeController();
            var result = controller.Index() as ViewResult;
            //Act
            var drinkList = (List<Drink>?)result?.ViewData.Model;
            //Assert
            Assert.Equal(4, drinkList?.Count);
        }

        [Fact]
        public void Test_Details_RedirectToIndex_IfIdLessThanOne()
        {
            var controller = new HomeController();
            var result = (RedirectToActionResult)controller.Drink(-1);
            Assert.Equal("Index", result.ActionName);
        }

        [Fact]
        public void Test_Details_Returns_ViewName()
        {
            var controller = new HomeController();
            var result = controller.Drink(2) as ViewResult;
            Assert.Equal("Drink", result?.ViewName);
        }
    }
}
