﻿using DataAccess.Entities;
using DataAccess.Repository;
using HotDrinkMachine.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace HotDrinkMachine.Controllers
{
    public class HomeController : Controller
    {
        IDrinkOperationRepository _DrinkOperationRepository;
        IDrinkRepository _DrinkRepository;

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger,IDrinkRepository DrinkRepository, IDrinkOperationRepository DrinkOperationRepository)
        {
            _logger = logger;
            _DrinkOperationRepository = DrinkOperationRepository;
            _DrinkRepository = DrinkRepository;
        }

        public HomeController()
        {
        }

        public IActionResult Index()
        {
         List<Drink> drinklst= _DrinkRepository.GetAllDrink();
            return View(drinklst);
        }
        public IActionResult Drink(int drinkId)
        {
            if(drinkId <1)
                return RedirectToAction("index");

            List<DrinkTask> _drTasklst = _DrinkOperationRepository.GetDrinkOperationByDrinkID(drinkId);

            return View(_drTasklst);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}