using DataAccess.Entities; // for using AddDbContext, it is added.
using DataAccess.Repository;
using Microsoft.EntityFrameworkCore; // for using UseSqlServer, it is added

//DI Container
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

//Reading settings from appsettings.json with configuration method since we can have some connection string and here we define which one should be used.
var cnn = builder.Configuration.GetConnectionString("HotDrinkMachinCnn");

//First Dependency injection
builder.Services.AddDbContext<DrinkMachineDbContext>(options => options.UseSqlServer(cnn));

//Second Dependency Injection
// for each interface there are some implementation, here we define which inplementation is needed.
// AddScope, AddTransient, Add...
//in each request for IProductRepository , one ProductRepository is created
builder.Services.AddScoped<IDrinkOperationRepository, DrinkOperationRepository>();
builder.Services.AddScoped<IDrinkRepository, DrinkRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();



//app.UseAuthentication();
//app.UseAuthorization();



app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

//app.MapGet("/", () => {
//    return "Hello World!";
//});

app.Run();
