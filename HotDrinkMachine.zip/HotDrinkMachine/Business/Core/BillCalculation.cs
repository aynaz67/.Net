﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Core
{
    public class BillCalculation
    {
        public double BillDiscountCalculation(double x)
        {
            if (x < 0)
                throw new ArgumentException("{x} is less thatn 0");

            return (x - ((10 * x) / 100));
        }
    }
}
