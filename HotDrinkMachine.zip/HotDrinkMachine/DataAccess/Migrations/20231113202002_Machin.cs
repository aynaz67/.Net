﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataAccess.Migrations
{
    public partial class Machin : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Drinks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Drinks", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Operations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Task = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Operations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DrinkOperations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DrinkId = table.Column<int>(type: "int", nullable: false),
                    OperationId = table.Column<int>(type: "int", nullable: false),
                    Sequence = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DrinkOperations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DrinkOperations_Drinks_DrinkId",
                        column: x => x.DrinkId,
                        principalTable: "Drinks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DrinkOperations_Operations_OperationId",
                        column: x => x.OperationId,
                        principalTable: "Operations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Drinks",
                columns: new[] { "Id", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "LemonTea", 10m },
                    { 2, "Coffee", 15m },
                    { 3, "Chocolate", 7m }
                });

            migrationBuilder.InsertData(
                table: "Operations",
                columns: new[] { "Id", "Task" },
                values: new object[,]
                {
                    { 1, "Boil some water" },
                    { 2, "Steep the water in the tea" },
                    { 3, "Pour Tea in the cup" },
                    { 4, "Add  lemon" },
                    { 5, "Brew the coffee ground" },
                    { 6, "Pour Coffe in the cup" },
                    { 7, "Add suger and milk" },
                    { 8, "Add drinking chocolate powder to the water" },
                    { 9, "Pour Chocolate in the cup" }
                });

            migrationBuilder.InsertData(
                table: "DrinkOperations",
                columns: new[] { "Id", "DrinkId", "OperationId", "Sequence" },
                values: new object[,]
                {
                    { 1, 1, 1, 1 },
                    { 2, 1, 2, 2 },
                    { 3, 1, 3, 3 },
                    { 4, 1, 4, 4 },
                    { 5, 2, 1, 1 },
                    { 6, 2, 5, 2 },
                    { 7, 2, 6, 3 },
                    { 8, 2, 7, 4 },
                    { 9, 3, 1, 1 },
                    { 10, 3, 8, 2 },
                    { 11, 3, 9, 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_DrinkOperations_DrinkId",
                table: "DrinkOperations",
                column: "DrinkId");

            migrationBuilder.CreateIndex(
                name: "IX_DrinkOperations_OperationId",
                table: "DrinkOperations",
                column: "OperationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DrinkOperations");

            migrationBuilder.DropTable(
                name: "Drinks");

            migrationBuilder.DropTable(
                name: "Operations");
        }
    }
}
