﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    public class DrinkMachineDbContext : DbContext
    {
        public DrinkMachineDbContext(DbContextOptions options) : base(options) { }

        public virtual DbSet<Drink> Drinks { get; set; }
        public virtual DbSet<Operation> Operations { get; set; }
        public virtual DbSet<DrinkOperation> DrinkOperations { get; set; }

        // Initial value for table
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Drink>().HasData(
                new Drink
                {
                    Name = "LemonTea",
                    Price = 10,
                    Id = 1
                },
                new Drink
                {
                    Name = "Coffee",
                    Price = 15,
                    Id = 2
                },
                new Drink
                {
                    Name = "Chocolate",
                    Price = 7,
                    Id = 3
                }
                );

            modelBuilder.Entity<Operation>().HasData(
                new Operation
                {
                    Id = 1,
                    Task = "Boil some water"
                },
                new Operation
                {
                    Id = 2,
                    Task = "Steep the water in the tea"
                },
                new Operation
                {
                    Id = 3,
                    Task = "Pour Tea in the cup"
                },
                new Operation
                {
                    Id = 4,
                    Task = "Add  lemon"
                },
                new Operation
                {
                    Id = 5,
                    Task = "Brew the coffee ground"
                },
                new Operation
                {
                    Id = 6,
                    Task = "Pour Coffe in the cup"
                },
                new Operation
                {
                    Id = 7,
                    Task = "Add suger and milk"
                },
                new Operation
                {
                    Id = 8,
                    Task = "Add drinking chocolate powder to the water"
                },
                new Operation
                {
                    Id = 9,
                    Task = "Pour Chocolate in the cup"
                }
                );

            modelBuilder.Entity<DrinkOperation>().HasData(
               new DrinkOperation
               {
                   Id = 1,
                   DrinkId = 1,
                   OperationId = 1,
                   Sequence = 1
               },
               new DrinkOperation
               {
                   Id = 2,
                   DrinkId = 1,
                   OperationId = 2,
                   Sequence = 2
               },
               new DrinkOperation
               {
                   Id = 3,
                   DrinkId = 1,
                   OperationId = 3,
                   Sequence = 3
               },
               new DrinkOperation
               {
                   Id = 4,
                   DrinkId = 1,
                   OperationId = 4,
                   Sequence = 4
               },
               new DrinkOperation
               {
                   Id = 5,
                   DrinkId = 2,
                   OperationId = 1,
                   Sequence = 1
               },
               new DrinkOperation
               {
                   Id = 6,
                   DrinkId = 2,
                   OperationId = 5,
                   Sequence = 2
               },
               new DrinkOperation
               {
                   Id = 7,
                   DrinkId = 2,
                   OperationId = 6,
                   Sequence = 3
               },
               new DrinkOperation
               {
                   Id = 8,
                   DrinkId = 2,
                   OperationId = 7,
                   Sequence = 4
               },
               new DrinkOperation
               {
                   Id = 9,
                   DrinkId = 3,
                   OperationId = 1,
                   Sequence = 1
               },
               new DrinkOperation
               {
                   Id = 10,
                   DrinkId = 3,
                   OperationId = 8,
                   Sequence = 2
               },
               new DrinkOperation
               {
                   Id = 11,
                   DrinkId = 3,
                   OperationId = 9,
                   Sequence = 3
               }
               );
        }
    }
}
