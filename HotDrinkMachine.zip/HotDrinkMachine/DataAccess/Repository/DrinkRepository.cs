﻿using DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class DrinkRepository : IDrinkRepository
    {
        DrinkMachineDbContext _db;
        public DrinkRepository(DrinkMachineDbContext db) {
                
            _db = db;
        }
        public List<Drink> GetAllDrink()
        {
          return  _db.Drinks.ToList();
        }
    }
}
