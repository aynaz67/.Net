﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class DrinkOperationRepository : IDrinkOperationRepository
    {
        private DrinkMachineDbContext _db;

        public DrinkOperationRepository(DrinkMachineDbContext db)
        {
            _db = db;
        }
        public List<DrinkTask> GetDrinkOperationByDrinkID(int DrinkID)
        {
            // return _db.DrinkOperations.Where(x => x.DrinkId == DrinkID).OrderBy(x=>x.Sequence).ToList();

            //        return _db.DrinkOperations.Join(_db.Operations,
            //                _DrinkOP => _DrinkOP.OperationId,
            //                _OP => _OP.Id,
            //              (_DrinkOP, _OP) => new DrinkTask
            //              {
            //                  DrinkId = _DrinkOP.DrinkId,
            //                  Task = _OP.Task,
            //                  Sequence = _DrinkOP.Sequence
            //              }

            //).Where(x => x.DrinkId == DrinkID).OrderBy(x => x.Sequence).ToList();




           var data =(from DrinkOP in _db.DrinkOperations
                    join OP in _db.Operations
                    on DrinkOP.OperationId equals OP.Id
                    where DrinkOP.DrinkId == DrinkID
                    orderby DrinkOP.Sequence
                    select new DrinkTask
                    {
                        DrinkId = DrinkOP.DrinkId,
                        Task = OP.Task,
                        Sequence = DrinkOP.Sequence
                    }
                    ).ToList();
            return data;

        }
    }
}