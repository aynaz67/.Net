﻿using Business.Core;
using NUnit.Framework;

namespace Nunit_Test
{
    [TestFixture]
    public class HotDrinkMachinTest
    {
        BillCalculation billCAll = new BillCalculation();

        //[Test] // this attribiute enable function to be testable
        //public void BillDiscountCalculation_Test()
        //{
        //    var result = billCAll.BillDiscountCalculation(30.50);

        //    //the first argument is the result that expected and the second argument is what is the real result
        //    Assert.AreEqual(27.45, result);
        //}

        [Test]
        // if the result was successful it mean it had exception otherwise the result is unsuccessful   
        public void BillDiscountCalculation_Exception_Test()
        {
            Assert.Catch<ArgumentException>(() => billCAll.BillDiscountCalculation(1));
        }

        [Ignore("Ignore-Test")] //this attribute ignore testing this method
        //if you run the test you can see this method is not in Test Explorer
        public void HandleInheritability()
        {

        }
    }
}