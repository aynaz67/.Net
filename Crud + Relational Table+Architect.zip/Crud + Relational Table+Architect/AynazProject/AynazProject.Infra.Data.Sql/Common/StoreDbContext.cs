﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace WebApplication1.Models
{
    public class StoreDbContext : DbContext
    {
        //1- which connection string
        public StoreDbContext(DbContextOptions options) : base(options) { }

        //2- which model
        public DbSet<Product> products { get; set; }
        public DbSet<Category> Categories { get; set; }

        //3- optional: initial value for table
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    Name = "Moile",
                    Id = 1
                },
                new Category
                {
                    Name = "Car",
                    Id = 2
                }
                );

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Name = "Iphone17",
                    Id = 1,
                    CategoryId = 1,
                    Price = 12000,
                    Description = "it nedd to be changed",
                },
                new Product
                {
                    Name = "Bez",
                    Id = 2,
                    CategoryId = 2,
                    Price = 12000,
                    Description = "it nedd to be changed",
                }
                );
        }
    }
}
