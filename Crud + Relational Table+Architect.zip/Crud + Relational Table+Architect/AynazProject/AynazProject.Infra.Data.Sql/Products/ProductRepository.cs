﻿namespace WebApplication1.Models
{
    public class ProductRepository : IProductRepository
    {
        private readonly StoreDbContext _context;

        //dependency inversion
        // here i define which db and tables i should use
        // top level define the connection not low level
        public ProductRepository(StoreDbContext context)
        {
            _context = context;
        }

        public List<Product> GetAll(int pageNumber, int pageSize)
        {
            // return _context.products.ToList();

            //remove (pageNumber - 1) page sizes when you are in a page number
            //then take page size
            // if dont want to select a special category it should be write string.IsNullOrWhiteSpace(category)

            // inner join Product and Category in linq
            return _context.products.Skip((pageNumber - 1) * pageSize).Take(pageSize)./*Where(p => string.IsNullOrWhiteSpace(categoryName) || p.Category.Name == categoryName)*/ToList();
        }

        public void DeleteAll()
        {
            _context.Dispose();
            Save();
        }

        public void AddProduct(Product product)
        {
            _context.products.Add(product);
            Save();
        }

        public void UpdateProduct(Product product)
        {
            var p = _context.products.Find(product.Id);
            if (p != null)
            {
                p.Name = product.Name;
                p.Price = product.Price;
                p.CategoryId = product.CategoryId;
                p.Description = product.Description;
                _context.Update(p);
                Save();
            }
        }

        public void DeleteProduct(int productId)
        {
            var p = _context.products.Find(productId);
            if (p != null)
                _context.products.Remove(p);
            Save();
        }

        public Product GeProductById(int productId)
        {
            var p = _context.products.Find(productId);
            return p;
        }

        //DRY Principle
        private void Save()
        {
            _context.SaveChanges();
        }
    }
}