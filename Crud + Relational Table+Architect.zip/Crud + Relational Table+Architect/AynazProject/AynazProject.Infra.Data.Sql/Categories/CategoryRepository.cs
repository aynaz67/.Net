﻿namespace WebApplication1.Models
{
    public class CategoryRepository : ICategoryRepository
    {
        StoreDbContext _context;
        public CategoryRepository(StoreDbContext dbContext)
        {
            _context = dbContext;
        }
        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public Category GetCategoryById(int id)
        {
            return _context.Categories.Find(id);
        }
    }
}
