﻿namespace AynazProject.Infra.Data.Sql
{
    public class Class1
    {

    }
}