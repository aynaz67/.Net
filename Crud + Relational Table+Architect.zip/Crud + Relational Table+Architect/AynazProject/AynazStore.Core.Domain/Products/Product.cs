﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Product
    {
        public int Id { get; set; }

        public string Name { get; set; }     

        public string Description { get; set; }

        public int Price { get; set; }

        [ForeignKey("Category")]// create relation between primary key of Category table and CategoryId from product table
        public int CategoryId { get; set; } // id +table name => Foreign Key
        public virtual Category Categories { get; set; } // relation with Category Table
    }
}
