﻿namespace WebApplication1.Models
{
    public interface IProductRepository
    {
        List<Product> GetAll(int pageNumber, int pageSize);
        Product GeProductById(int productId);
        void AddProduct(Product product);
        void UpdateProduct(Product product);
        void DeleteProduct(int productId);
    }
}
