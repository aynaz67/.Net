﻿namespace WebApplication1.Models
{
    public interface ICategoryRepository
    {
        public List<Category> GetAllCategories();
        public Category GetCategoryById(int id);

    }
}
