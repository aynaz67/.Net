﻿namespace AynazStore.Core.Domain
{
    public class Class1
    {

    }
}