﻿namespace WebApplication1.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Category Category { get; set; } // relation with Category Table
        public int CategoryId { get; set; } // id +table name => Foreign Key
        public string Description { get; set; }
        public int Price { get; set; }
    }
}
