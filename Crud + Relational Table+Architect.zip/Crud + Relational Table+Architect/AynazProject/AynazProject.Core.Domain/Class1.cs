﻿namespace AynazProject.Core.Domain
{
    public class Class1
    {

    }
}
