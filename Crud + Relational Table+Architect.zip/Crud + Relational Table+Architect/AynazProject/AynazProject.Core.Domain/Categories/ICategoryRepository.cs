﻿namespace WebApplication1.Models
{
    public interface ICategoryRepository
    {
        public List<string> GetAllCategories();
        public Category GetCategoryById(int id);
    }
}
