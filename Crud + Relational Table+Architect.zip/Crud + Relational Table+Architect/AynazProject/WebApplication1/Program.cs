using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

//DI Container
// 1- creating an instance of web application builder which is used for configuration
var builder = WebApplication.CreateBuilder(args);

//Depedencies related to Mvc is added - it should before builder.build
builder.Services.AddControllersWithViews();

//Reading settings from appsettings with configuration method
var cnn = builder.Configuration.GetConnectionString("storeCnn");

//Dependency injection
builder.Services.AddDbContext<StoreDbContext>(options => options.UseSqlServer(cnn));

//Injection
//in each request for IProductRepository , one ProductRepository is created
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();


//2- creating web application (asp.net core web application) class by builder instance
var app = builder.Build();

// 4 middlewares

//1- exception detail
app.UseDeveloperExceptionPage();

//2-status code exception in a page
app.UseStatusCodePages();

//3- using static files
app.UseStaticFiles();

//4- addressing 
app.UseRouting();
app.UseEndpoints(endpoints => endpoints.MapControllerRoute("Pagination", "/{controller=home}/{action=index}/{pageNumber}"));
app.UseEndpoints(endpoints => endpoints.MapDefaultControllerRoute());

//5- route middelware
//app.MapGet("/", () => "Hello World!");



// localhost:5050  this is a url that the application is hosted on 
// multiple middlewares can be run on a request and they run base on the order that thay are defined
// I should add taht the next middleware shoulde be call from the previous middleware otherwise the next 
//middle ware will not executed.
//middleware that use Run method can not run the next middleware

// a middleware
//app.Run(async (HttpContext context) =>
//{
//    await context.Response.WriteAsync("hiiiiiiiiii im aynaz");
//}
//    );

//3- start server
// the web application will be hosted on this server
app.Run();

