﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        IProductRepository _productRepository;
        ICategoryRepository _categoryRepository;
        int pageSize = 20;

        public HomeController(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        // default value of pageNumber is 1
        //pageNumber is optional variable and it is located in last parameter 
        public IActionResult Index(int pageNumber = 1)
        {
            var p = _productRepository.GetAll(pageNumber, pageSize);
            return View(p);
        }

        public IActionResult Detail(int id = 1)
        {
            return View(_productRepository.GeProductById(id));
        }

        // default - it is HttpGet
        // default value of id =0
        public IActionResult CreateOrEdit(int id = 0)
        {
            ViewBag.CategoryList = CreateCategoryList();

            if (id == 0) //create
            {
                return View(new Product());// we use this objects only for conditions in html like model.id
            }
            // Edit
            var product = _productRepository.GeProductById(id);
            if (product == null)
            {
                TempData["ErroreMessage"] = "product with this ID could not find";
                return RedirectToAction("Index");
            }
            return View(product);
        }

        [HttpPost]
        public IActionResult CreateOrEdit(Product product)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (product.Id == 0)// create
                    {
                        _productRepository.AddProduct(product);
                        TempData["SuccessMessage"] = "Successfully product is created";
                        return RedirectToAction("Index");
                    }
                    else // EDit
                    {
                        _productRepository.UpdateProduct(product);
                        TempData["SuccessMessage"] = "Successfully product is Updated";
                        return RedirectToAction("Index");
                    }
                }
                else
                {
                    TempData["ErroreMessage"] = "Invalid Model State";
                    return View();
                }
            }
            catch (Exception ex)
            {
                TempData["ErroreMessage"] = ex.Message;
                return View();
            }
        }

        public IActionResult Delete(int id)
        {
            try
            {
                _productRepository.DeleteProduct(id);
                TempData["SuccessMessage"] = "Item deleted Successfully";
            }
            catch (Exception ex)
            {
                TempData["ErroreMessage"] = ex.Message;
            }
            return RedirectToAction("Index");

            //try
            //{
            //    if (id != 0)
            //    {
            //        _productRepository.DeleteProduct(id);
            //        TempData["SuccessMessage"] = "Item deleted Successfully";
            //    }
            //    else
            //        TempData["ErroreMessage"] = "id could not find";

            //}
            //catch (Exception ex)
            //{
            //    TempData["ErroreMessage"] = ex.Message;
            //}
            //return RedirectToAction("Index");

        }

        public List<SelectListItem> CreateCategoryList()
        {
            //for dropdown
            List<SelectListItem> categoryList = _categoryRepository.GetAllCategories().Select(c => new SelectListItem
            {
                Text = c.Name,
                Value = c.Id.ToString()
            }
          ).ToList();

            var initial = new SelectListItem { Text = "---Select Category---", Value = " " };
            categoryList.Insert(0, initial);
            return categoryList;
        }
    }
}

